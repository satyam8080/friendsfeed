</body>

</html><?php /**PATH D:\Projects\xampp\htdocs\abc\resources\views/templates/footer.blade.php ENDPATH**/ ?>