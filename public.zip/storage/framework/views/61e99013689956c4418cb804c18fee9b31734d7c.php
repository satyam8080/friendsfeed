</body>

</html><?php /**PATH D:\Projects\xampp\htdocs\friendsfeed\resources\views/templates/footer.blade.php ENDPATH**/ ?>