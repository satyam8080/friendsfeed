<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->make('templates.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('asset/css/searchadv.css')); ?>" rel="stylesheet">

<!--From card-->

<?php if($data != '' ): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width: 37rem;  margin:auto; margin-top : 2rem;">
     <div class="card-header" style="padding-bottom:.5rem !important; background-color:white;border:none;">

        <img src="<?php echo e(asset('asset/images/raj.jpg')); ?>" alt="" class="float-left rounded-circle" style="height: 4rem; width: 4rem;">

  
        <div style="height:100%; float:left; padding-left:1rem;padding-top:1rem;">
 
    <h5 class="card-title" style=" line-height:1rem !important;"> <?php echo e($search->name); ?> </h5>
            <p style="line-height:.1rem;"><a style="text-decoration:none; display:inline;font-size:.8rem; color:#06216a; cursor:pointer;" href="<?php echo e(URL('user/'.$search->id)); ?> "><?php echo e('@'.$search->username); ?></a></p>
        </div>
    </div>
     <div class="card-body">
         <i class="fa fa-id-card fa-lg"></i>
             <b>
             Hello boys! Chai pe lo
             </b>
         
         </div>
</div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\Projects\xampp\htdocs\friendsfeed\resources\views/pages/search.blade.php ENDPATH**/ ?>